import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Hashtable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.google.gson.Gson;

@XmlRootElement
public class Profile {
	private String key;
	private Hashtable<String, String> info;

	void log(String yyy)
	{
		PrintWriter writer;
		try {
			writer = new PrintWriter("c:\\temp\\ddd.txt", "UTF-8");
			writer.println(yyy);
			writer.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Profile() 
	{
	//	log("Default construcctor");
	}
	public Profile(String aKey, Hashtable<String, String> anInfo )
	{
		key = aKey;
		info = anInfo;
	}
	@Override
	public String toString()	{
		String result = "Key: " + key + '\n';
		if (info != null) {
			for(String aKey: info.keySet()){
				result += "Field: " + aKey + '\n';
				result += "Value: " + info.get(aKey);	
			}
		}
		return result;
	}
	public String modify(String field, String newValue) {
		String msg = "Field: " + field + " was not found";
		for (String aKey: info.keySet()) {
			if (field.equals(aKey)) {
				msg += "Old Value: " + info.replace(aKey, newValue) + '\n';
				msg += "New Value: " + newValue + '\n';
				break;
			}
		}
		return msg;
	}
	public String toJson() {
		Gson gson = new Gson();
		return gson.toJson(this);
	}
	public Hashtable<String, String> getInfo() {
		return info;
	}
	@XmlElement 
	public void setKey(String key) {
		//log("setKey(" + key + ")");
		this.key = key;
	}
	@XmlElement
	public void setInfo(Hashtable<String, String> info) {
		//log("setInfo(" + info + ")");
		this.info = info;
	}
	public String getKey() {
		return key;
	}
	
}
