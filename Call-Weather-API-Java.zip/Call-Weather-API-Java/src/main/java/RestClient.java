import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import com.google.gson.Gson;
//Google OAuth2.0: My First Project 22807
//Client-ID: 872370762969-9faip0bgn4cg1j2t6smljkoju5uk52tl.apps.googleusercontent.com
//Client secret: M5xoHOcDWNvmhuhb7x9rASSC
public class RestClient {
/*var CLIENT_ID = '6b284830006843e7ae7b170725715aed';
        var REDIRECT_URI = 'http://jmperezperez.com/spotify-oauth-jsfiddle-proxy/';
        function getLoginURL(scopes) {
            return 'https://accounts.spotify.com/authorize?client_id=' + CLIENT_ID +
              '&redirect_uri=' + encodeURIComponent(REDIRECT_URI) +
              '&scope=' + encodeURIComponent(scopes.join(' ')) +
              '&response_type=token';
        }
    private final String CLIENT_ID="6b284830006843e7ae7b170725715aed";
	private final String CLIENT_SECRET="M5xoHOcDWNvmhuhb7x9rASSC";
        
 * 
 */
	// http://localhost:8080/RESTfulExample/json/product/get
	
	public static void main(String[] args) {
		weatherAPI(); //--> was not OAuth2.0
		
		/*CallMyProfilesAPI.getProfilesMyAPI();
		serializeProfileAndPostToMyAPI();
		getProfilesMyAPI();
		deserializeProfileFromMyAPI();*/
	  
		
		//working();
		//test();   http://localhost:8080/ProfileManagerMongoDB/rest/ProfileService/list
	  
	}
	public static void weatherAPI() {
		try {
			//4119972 = Lowell
			String city_id="4119972";
			String API_Key="ed79f598c64105bb9e6bcfb9b430b593";
			URL url = new URL("http://api.openweathermap.org/data/2.5/forecast?id=" 
			+ city_id+ "&APPID=" + API_Key);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
				(conn.getInputStream())));

			String output;
			
			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {
				System.out.println(output);
				Gson gson = new Gson();
				WeatherMsgObject temp = gson.fromJson(output, WeatherMsgObject.class);
				System.out.println(temp.toString());
			}
			conn.disconnect();

		  } catch (MalformedURLException e) {

			e.printStackTrace();

		  } catch (IOException e) {

			e.printStackTrace();

		  }
	}
	public static void emotionAPI() {
		 HttpClient httpClient = new DefaultHttpClient();
	        try
	        {
	            // NOTE: You must use the same region in your REST call as you used to obtain your subscription keys.
	            //   For example, if you obtained your subscription keys from westcentralus, replace "westus" in the
	            //   URL below with "westcentralus".
	            URIBuilder uriBuilder = new URIBuilder("https://westus.api.cognitive.microsoft.com/emotion/v1.0/recognize");

	            URI uri = uriBuilder.build();
	            HttpPost request = new HttpPost(uri);

	            // Request headers. Replace the example key below with your valid subscription key.
	            request.setHeader("Content-Type", "application/json");
	            request.setHeader("Ocp-Apim-Subscription-Key", "13hc77781f7e4b19b5fcdd72a8df7156");

	            // Request body. Replace the example URL below with the URL of the image you want to analyze.
	            StringEntity reqEntity = new StringEntity("{ \"url\": \"http://random.cat/view/1199\" }");
	            request.setEntity(reqEntity);

	            HttpResponse response = httpClient.execute(request);
	            HttpEntity entity = response.getEntity();

	            if (entity != null)
	            {
	                System.out.println(EntityUtils.toString(entity));
	            }
	        }
	        catch (Exception e)
	        {
	            System.out.println(e.getMessage());
	        }
		
	}
	
}