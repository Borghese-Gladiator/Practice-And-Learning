var arr = [];
fetch('http://localhost:5000/movie')
  .then(response => response.json())
  .then(function(json) {
    json = JSON.parse(json)
    for(let movie of json) {
       console.log(movie)
	   arr = movie;
    }
  })