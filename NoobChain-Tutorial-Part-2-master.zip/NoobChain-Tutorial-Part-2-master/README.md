# NoobChain-Tutorial-Part-2
A Simple Java Blockchain for educational purposes.

This is for https://medium.com/programmers-blockchain/create-simple-blockchain-java-tutorial-from-scratch-6eeed3cb03fa tutorial. 

*If you have any other questions you can message me on the [Blockchain Developers Club](https://discord.gg/ZsyQqyk) discord server.*

A simple Java blockchain with transactions. ( Still missing networking )

# Dependencies: You will need to import Both Bouncy castle and GSON:
- bouncy castle [bcprov-jdk15on-159.jar ](https://www.bouncycastle.org/download/bcprov-jdk15on-159.jar)
- gson [gson-2.8.2.jar](http://central.maven.org/maven2/com/google/code/gson/gson/2.8.2/gson-2.8.2.jar)

# Java Version:
- *JDK1.8.0_77*

contact: kassCrypto@gmail.com
