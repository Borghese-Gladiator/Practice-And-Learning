package service;

public class AFunction {
	private String functionName;
	public AFunction() {}
	public AFunction(String functionName) {
		this.functionName = functionName;
	}
	public String getFunctionName() {
		return functionName;
	}
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}
}
