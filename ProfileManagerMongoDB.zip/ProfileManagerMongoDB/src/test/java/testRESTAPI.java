/*import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.json.JsonObject;
import javax.json.JsonValue;

import org.junit.Test;

public class testRESTAPI {

	@Test
	public void test() {
		JsonObject in = new JsonObject();
		Hashtable<String, String> temp = new Hashtable<String, String>();
		temp.put("Name: ", "J_Shee");
		JsonValue x = new JsonValue();
		x.asJsonArray();
		x.
		in.put
		in.put("info", temp);
		
				"[{"info":{"Name": "J_Shee" }, "key": "7" }]";
	}
	public static <T> T retrieveResourceFromResponse(HttpResponse response, Class<T> clazz) 
			  throws IOException {
			  
			    String jsonFromResponse = EntityUtils.toString(response.getEntity());
			    ObjectMapper mapper = new ObjectMapper()
			      .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			    return mapper.readValue(jsonFromResponse, clazz);
			}
	@Test
	public void givenUserDoesNotExists_whenUserInfoIsRetrieved_then404IsReceived()
	  throws ClientProtocolException, IOException {
	  
	   // Given
	   String name = RandomStringUtils.randomAlphabetic( 8 );
	   HttpUriRequest request = new HttpGet( "https://api.github.com/users/" + name );
	 
	   // When
	   HttpResponse httpResponse = HttpClientBuilder.create().build().execute( request );
	 
	   // Then
	   assertThat(
	     httpResponse.getStatusLine().getStatusCode(),
	     equalTo(HttpStatus.SC_NOT_FOUND));
	}

}
*/